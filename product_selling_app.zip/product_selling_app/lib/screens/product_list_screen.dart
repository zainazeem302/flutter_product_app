import 'package:flutter/material.dart';
import '../models/product.dart';
import '../widgets/product_title.dart';

class ProductListScreen extends StatelessWidget {
  final List<Product> products = [
    Product(
      id: 'p1',
      title: 'Doungle',
      description: 'Amazing device to connect from pc to ptcl',
      imageUrl: 'https://smartsensordevices.com/wp-content/uploads/2022/05/smartusbdongle2.jpg',
      price: 29.99,
    ),
    Product(
      id: 'p2',
      title: 'Product 2',
      description: 'Description of product 2',
      imageUrl: 'https://www.google.com/url?sa=i&url=https%3A%2F%2Fen.wikipedia.org%2Fwiki%2FCar&psig=AOvVaw1luiBnrdw0_RtGRuymwtXC&ust=1728140285163000&source=images&cd=vfe&opi=89978449&ved=0CBcQjhxqFwoTCKCppbL-9IgDFQAAAAAdAAAAABAI',
      price: 19.99,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Product List'),
      ),
      body: ListView.builder(
        itemCount: products.length,
        itemBuilder: (context, index) {
          return ProductTile(product: products[index]);
        },
      ),
    );
  }
}
